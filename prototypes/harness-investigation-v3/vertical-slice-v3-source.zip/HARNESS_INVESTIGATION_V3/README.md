# The Harness: Who Do You Trust? — Cinematic Investigation V3
**2026-10-10 • separate standalone web prototype • not an Android APK or official release**

## What changed from approved V2
The opening (title, physical relay, unexpected signal, permanent/readable mission sheet, character introductions) is preserved. V3 replaces V2's two-clue placeholder ending with a visual forensic control room using actual Episode 001 evidence and the original game-rule reducer. The player can inspect up to five original evidence reports, consult BOY/TOOTH/LUKE/DON SOL, discover a hidden clock report only after asking BOY, re-consult TOOTH after the new facts, unlock or fail to unlock an evidence-dependent fourth decision, see the original consequences, and review an evidence-based postmortem.

New editable evidence card illustrations: `art/evidence-*.svg`. The same three original preview WAVs remain. Sound is enabled by default and starts from an explicit user tap; Android sound has **not** been verified or fixed by this prototype.

## How to play
Download the single HTML preview and open in Chrome or Edge, with no network or installation required. Read the story at your own pace. Meet the advisers, enter the evidence room, tap sources to read them, question advisers more than once, then review the four potential responses. The final combined safety option is intentionally locked until key evidence is inspected. There is **no timed instruction playback**.

## Protection / limitations
* No changes to the official APK, project source, Drive folders, or device saves. Entire game-play source is a separately staged prototype.
* Byte-for-byte copies of original game rule modules (`canonical_core/*.js`) and Episode 001 data (`data/episode-001.json`) are included. `canonical-core-bundle.js` simply wraps them for offline use.
* This exploratory shell does not persist saves, synchronize to a phone, or certify a real Android sound implementation.
* Chrome/Edge browser QA and Android QA are distinct; successful Node tests do not establish visual quality or audible device output.

## Test
`node --test tests/*.test.mjs`

See `QA_REPORT.md` and `QA_SHA256_MANIFEST.json` for reported evidence and hashes.
