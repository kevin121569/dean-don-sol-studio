'use strict';
// V3 PRESENTATION PROTOTYPE. Canonical Episode 001 content and pure reducer are copied unchanged.
// This page does not read/write the official game's save key or alter official APK/source.
const $ = id => document.getElementById(id);
const CORE = window.HarnessCore, EPISODE = window.HarnessEpisode;
const A = CORE.ACTIONS;
const GAME = $('game');
const SCENES = ['title','isolation','anomaly','briefing','crew','investigation','decision','outcome','debrief'];
const AUDIO = {music:$('soundtrack'),ack:$('ack'),alarm:$('alarm')};
let currentScene='title', soundWanted=true, everActivated=false, currentRecord=null, currentAdvice=null, selectedDecision=null;
let state=CORE.createInitialState(EPISODE);
const PREVIEWS={
 boy:{role:'BOY / THE SEARCHER',quote:'“I can find every signal in the records. That doesn’t mean I know which one to trust.”'},
 tooth:{role:'TOOTH / THE FACT-CHECKER',quote:'“Before anyone hits shutdown, I want to know what the evidence actually proves.”'},
 luke:{role:'LUKE / THE WORST-CASE THINKER',quote:'“If it is dangerous, delay could cost us. But suspicion isn’t proof.”'},
 donsol:{role:'DON SOL / THE TEAM LEAD',quote:'“Four opinions. One decision. None of us gets to make it for you.”'}
};
const imgs={e_monitor:'monitor',e_controller:'controller',e_technician:'person',e_protocol:'protocol',e_clocksync:'clock'};
const shortNames={e_monitor:'01 · THE ALARM',e_controller:'02 · LOCKDOWN RECORD',e_technician:'03 · NIGHT TECH',e_protocol:'04 · RULEBOOK',e_clocksync:'NEW · CLOCK REPORT'};
const advisorNames={boy:'BOY',tooth:'TOOTH',darth:'LUKE',donsol:'DON SOL'};
const esc=s=>String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function dispatch(action){const next=CORE.reduce(state,action,EPISODE);const changed=next!==state;state=next;return changed;}
function status(msg,error=false){const node=$('audioStatus');node.textContent=msg;node.classList.toggle('error',error)}
function updateMute(){ $('audioText').textContent=soundWanted?'SOUND ON':'SOUND OFF';$('audioToggle').setAttribute('aria-pressed',String(soundWanted));AUDIO.music.volume=.85;AUDIO.ack.volume=.9;AUDIO.alarm.volume=.85;}
function playMedia(media,success){
 if(!soundWanted)return;
 try {const result=media.play(); Promise.resolve(result).then(()=>{if(soundWanted&&currentScene!=='title')status(success||'BROWSER PLAYBACK STARTED · DEVICE OUTPUT NOT VERIFIED')}).catch(err=>status('AUDIO BLOCKED: '+(err?.name||'unknown')+' · TAP SOUND TO RETRY',true));}
 catch(err){status('AUDIO ERROR: '+(err?.name||'unknown'),true)}
}
function unlockAudio(){everActivated=true;if(soundWanted){playMedia(AUDIO.music,'MUSIC STARTED IN BROWSER · CHECK YOUR SPEAKERS');playMedia(AUDIO.ack,'AUDIO START REQUESTED · CHECK SPEAKERS')}else status('SOUND MUTED')}
function sfx(name){if(!soundWanted||!everActivated)return;const m=AUDIO[name];try{m.pause();m.currentTime=0;playMedia(m,'SOUND EFFECT TRIGGERED')}catch(err){status('SOUND ERROR: '+(err?.name||'unknown'),true)}}
function transition(scene){
 if(!SCENES.includes(scene))throw Error('Unknown scene '+scene);
 currentScene=scene;GAME.dataset.scene=scene;
 for(const id of SCENES){const el=$('scene'+id[0].toUpperCase()+id.slice(1));el.hidden=id!==scene;}
 const n=SCENES.indexOf(scene);
 document.querySelectorAll('.seg').forEach((el,i)=>{el.classList.toggle('current',i===n);el.classList.toggle('done',i<n)});
 $('main').setAttribute('aria-label','Current story stage: '+scene);
 const target=$('scene'+scene[0].toUpperCase()+scene.slice(1)).querySelector('h1,h2');
 if(target){target.tabIndex=-1;target.focus({preventScroll:true})}
 window.scrollTo(0,0);
}
// First five scenes stay exactly in the V2 approved story order.
$('startButton').addEventListener('click',()=>{unlockAudio();transition('isolation')});
$('relayButton').addEventListener('click',()=>{transition('anomaly');sfx('alarm')});
$('commandButton').addEventListener('click',()=>{transition('briefing');sfx('ack')});
$('briefingNext').addEventListener('click',()=>{transition('crew');sfx('ack')});
$('missionAgain').addEventListener('click',()=>{transition('briefing');sfx('ack')});
for(const btn of document.querySelectorAll('.adviser')){
 btn.addEventListener('click',()=>{
  const who=btn.dataset.adviser;
  document.querySelectorAll('.adviser').forEach(b=>{const active=b===btn;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
  $('adviserRole').textContent=PREVIEWS[who].role;$('adviserQuote').textContent=PREVIEWS[who].quote;
  $('adviserCount').textContent='This is a character preview. You will question advisers about evidence in the investigation. Ask one, several, or all four—no vote is cast.';
  sfx('ack');
 });
}
$('missionButton').addEventListener('click',()=>{
 if(state.sceneId==='briefing')dispatch({type:A.START});
 renderEvidence();renderCounts();transition('investigation');sfx('ack');
});
function renderCounts(){
 const total=state.discoveredEvidence.length,read=state.inspectedSources.length;
 $('caseEvidenceCount').textContent=`${read} OF ${total} DISCOVERED RECORDS READ`;
 $('caseConsultCount').textContent=`${state.consultations.length} OF 4 ADVISERS CONSULTED`;
}
function renderEvidence(){
 const container=$('caseEvidenceList');container.replaceChildren();
 for(const id of state.discoveredEvidence){
  const evidence=EPISODE.evidence.find(e=>e.id===id);
  const read=state.inspectedSources.includes(id),active=id===currentRecord;
  const b=document.createElement('button');b.type='button';b.className='case-evidence-card'+(read?' read':'')+(active?' active':'');
  b.dataset.evidence=id;b.setAttribute('aria-pressed',String(active));
  b.innerHTML=`<img src="art/evidence-${imgs[id]}.svg" alt="" loading="lazy"/><span class="case-evidence-meta"><b>${esc(shortNames[id])}</b><small>${esc(evidence.source)}</small><em>${read?'REVIEW AGAIN':'OPEN RECORD'}</em></span><span class="case-chevron" aria-hidden="true">↗</span>`;
  b.addEventListener('click',()=>openRecord(id)); container.append(b);
 }
}
function openRecord(id){
 if(!state.discoveredEvidence.includes(id))return;
 dispatch({type:A.OPEN_EVIDENCE,evidenceId:id});currentRecord=id;
 const e=EPISODE.evidence.find(x=>x.id===id);
 $('caseReport').innerHTML=`<div class="report-art"><img src="art/evidence-${imgs[id]}.svg" alt="Abstract visual diagram of ${esc(e.title)}"></div><div class="report-text"><span class="report-docket">VERIFIED SOURCE VIEW / ${esc(e.source)}</span><h4>${esc(e.title)}</h4><p class="report-summary">${esc(e.summary)}</p><div class="report-findings">${e.body.map(line=>`<p>${esc(line)}</p>`).join('')}</div><p class="report-limit">Evidence is not proof of intent. Compare this source with the others.</p></div>`;
 renderEvidence();renderCounts();sfx('ack');
}
for(const button of document.querySelectorAll('[data-consult]')){
 button.addEventListener('click',()=>consult(button.dataset.consult));
}
function consult(id){
 if(state.sceneId!=='investigate')return;
 const wasFound=state.discoveredEvidence.length;
 dispatch({type:A.CONSULT,advisorId:id});currentAdvice=id;
 const consult=state.consultations.find(c=>c.advisorId===id);
 const entry=EPISODE.advice[id].find(v=>v.id===consult?.adviceId);
 if(!entry)return;
 $('caseAdvice').innerHTML=`<b><span class="advice-pulse">●</span> ${esc(advisorNames[id])} / RESPONSE RECEIVED</b><p>${esc(entry.text)}</p><small>${state.discoveredEvidence.length>wasFound?'NEW RECORD UNLOCKED IN EVIDENCE CONSOLE · ':''}Question them again when your findings change.</small>`;
 document.querySelectorAll('[data-consult]').forEach(b=>b.classList.toggle('active',b.dataset.consult===id));
 renderEvidence();renderCounts();sfx('ack');
}
$('returnMission').addEventListener('click',()=>{transition('briefing');sfx('ack')});
$('goDecision').addEventListener('click',()=>{if(state.sceneId==='investigate')dispatch({type:A.GO_TO_DECISION});selectedDecision=null;$('uncertaintyCheck').checked=false;renderDecisions();transition('decision');sfx('ack')});
function renderDecisions(){
 const root=$('decisionOptions');root.replaceChildren();
 for(const d of EPISODE.decisions){
  const enabled=CORE.isDecisionAvailable(state,EPISODE,d.id);
  const b=document.createElement('button');b.type='button';b.className='decision-card'+(enabled?'':' locked')+(selectedDecision===d.id?' selected':'');
  b.dataset.decision=d.id;b.setAttribute('role','radio');b.setAttribute('aria-checked',String(selectedDecision===d.id));b.disabled=!enabled;
  b.innerHTML=`<span class="decision-glyph" aria-hidden="true">${enabled?'◯':'◈'}</span><span><b>${esc(d.label)}</b><small>${esc(d.description)}</small><em>${enabled?esc(d.risk):'NOT YET AVAILABLE · Compare key records to uncover this option'}</em></span>`;
  b.addEventListener('click',()=>{selectedDecision=d.id;renderDecisions();updateDecisionButton();sfx('ack')});root.append(b);
 }
 updateDecisionButton();
}
function updateDecisionButton(){
 const ready=Boolean(selectedDecision&&$('uncertaintyCheck').checked);
 $('submitDecision').disabled=!ready;
 $('decisionHint').textContent=!selectedDecision?'Select a response. Your advisers do not choose for you.':!$('uncertaintyCheck').checked?'Acknowledge uncertainty to issue the order.':'Your order can now be issued. This changes the outcome.';
}
$('uncertaintyCheck').addEventListener('change',()=>{dispatch({type:A.ACKNOWLEDGE_UNCERTAINTY,value:$('uncertaintyCheck').checked});updateDecisionButton()});
$('backToEvidence').addEventListener('click',()=>{dispatch({type:A.BACK_TO_INVESTIGATION});renderEvidence();renderCounts();transition('investigation')});
$('submitDecision').addEventListener('click',()=>{
 if(!selectedDecision||!$('uncertaintyCheck').checked)return;
 if(!dispatch({type:A.SUBMIT_DECISION,decisionId:selectedDecision}))return;
 const d=EPISODE.decisions.find(x=>x.id===selectedDecision);
 $('outcomeTitle').textContent=d.outcome.heading;
 $('outcomeStory').textContent=d.outcome.text;
 $('outcomeRisk').textContent=d.risk;
 transition('outcome');sfx('alarm');
});
$('showDebrief').addEventListener('click',()=>{
 dispatch({type:A.VIEW_POSTMORTEM});
 const pm=CORE.buildPostmortem(state,EPISODE);
 const bullets=(arr)=>arr?.length?`<ul>${arr.map(s=>`<li>${esc(s)}</li>`).join('')}</ul>`:'<p>None recorded.</p>';
 $('debriefContent').innerHTML=`<div class="debrief-panel"><h3>What you inspected</h3>${bullets(pm.known)}</div><div class="debrief-panel"><h3>What remained uncertain</h3>${bullets(pm.unknown)}</div><div class="debrief-panel wide"><h3>Options you didn't choose</h3>${bullets(pm.alternatives.map(a=>`${a.label}: ${a.risk}`))}</div>`;
 transition('debrief');sfx('ack');
});
$('replayButton').addEventListener('click',()=>{dispatch({type:A.RESET});currentRecord=null;currentAdvice=null;selectedDecision=null;
 document.querySelectorAll('.adviser').forEach(b=>{const active=b.dataset.adviser==='boy';b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))});
 $('adviserRole').textContent=PREVIEWS.boy.role;$('adviserQuote').textContent=PREVIEWS.boy.quote;
 $('adviserCount').textContent='BOY is shown first. You can hear from the other three, too—optional.';
 $('caseReport').innerHTML='<div class="case-empty"><div class="case-empty-icon">◇</div><b>SELECT A RECORD</b><p>Open a source and examine what it actually establishes.</p></div>';
 $('caseAdvice').innerHTML='<b>ADVISER LINK AVAILABLE</b><p>Tap a name. If you uncover new evidence, ask them again.</p>';
 renderEvidence();renderCounts();transition('title');AUDIO.music.pause();status('AUDIO READY · TAP ENTER TO START')});
$('revisitMission').addEventListener('click',()=>$('helpDialog').showModal());
$('audioToggle').addEventListener('click',()=>{soundWanted=!soundWanted;updateMute();if(!soundWanted){Object.values(AUDIO).forEach(a=>a.pause());status('SOUND MUTED')}else{unlockAudio();status('SOUND ON · RETRYING PLAYBACK')}});
$('helpButton').addEventListener('click',()=>$('helpDialog').showModal());
$('closeHelp').addEventListener('click',()=>$('helpDialog').close());
document.addEventListener('visibilitychange',()=>{if(document.hidden){AUDIO.music.pause();if(soundWanted&&everActivated)status('SOUND PAUSED · APP BACKGROUNDED')}else if(soundWanted&&everActivated){playMedia(AUDIO.music,'BROWSER MUSIC RESUMED · DEVICE NOT VERIFIED')}});
for(const [name,media] of Object.entries(AUDIO))media.addEventListener('error',()=>status('AUDIO FILE ERROR: '+name,true));
updateMute();renderEvidence();renderCounts();transition('title');status('AUDIO READY · TAP ENTER TO START');
