import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const read=p=>readFileSync(path.join(root,p),'utf8');
const ctx={window:{}};vm.runInNewContext(read('canonical-core-bundle.js'),ctx);
const g=ctx.window.HarnessCore,ep=JSON.parse(read('data/episode-001.json')),A=g.ACTIONS;
const hash=p=>createHash('sha256').update(readFileSync(path.join(root,p))).digest('hex');
const pinned = {
 'canonical_core/advice.js': 'e9afc25309491640ce4ab217467adc94d9edc56cebb6726425b1a13ea85515cd',
 'canonical_core/engine.js': '7d543aa191870bd7c6ea978bdbb7df5f23bb2aec735ab35cde5cd77977c7734d',
 'canonical_core/state.js': 'ce323ada229fa874f4e5559cc3345406e631a708dc1da341fe946cd84b97a670',
 'data/episode-001.json': '743285383fd5ca17891c840feb41ea28bbdcb9d294d6503c874c8ec32d1f2819',
};
for(const p of ['advice.js','engine.js','state.js'])test('Canonical '+p+' unchanged',()=>{
 assert.equal(hash('canonical_core/'+p),pinned['canonical_core/'+p]);
});
test('Canonical episode content unchanged',()=>assert.equal(hash('data/episode-001.json'),pinned['data/episode-001.json']));
test('Game starts in briefing and all four visible clues are discoverable',()=>{let s=g.createInitialState(ep);assert.equal(s.sceneId,'briefing');assert.equal(s.discoveredEvidence.length,4);assert(!s.discoveredEvidence.includes('e_clocksync'));s=g.reduce(s,{type:A.START},ep);assert.equal(s.sceneId,'investigate')});
test('Hidden clock evidence only after BOY',()=>{let s=g.reduce(g.createInitialState(ep),{type:A.START},ep);const pre=g.reduce(s,{type:A.OPEN_EVIDENCE,evidenceId:'e_clocksync'},ep);assert.equal(pre,s);s=g.reduce(s,{type:A.CONSULT,advisorId:'boy'},ep);assert(s.discoveredEvidence.includes('e_clocksync'))});
test('TOOTH changes conclusion after reading exact records',()=>{let s=g.reduce(g.createInitialState(ep),{type:A.START},ep);for(const id of ['e_monitor','e_controller'])s=g.reduce(s,{type:A.OPEN_EVIDENCE,evidenceId:id},ep);s=g.reduce(s,{type:A.CONSULT,advisorId:'tooth'},ep);assert.equal(s.consultations[0].adviceId,'tooth_conflict');s=g.reduce(s,{type:A.CONSULT,advisorId:'boy'},ep);s=g.reduce(s,{type:A.OPEN_EVIDENCE,evidenceId:'e_clocksync'},ep);s=g.reduce(s,{type:A.CONSULT,advisorId:'tooth'},ep);assert.equal(s.consultations.find(x=>x.advisorId==='tooth').adviceId,'tooth_reconciled')});
test('Hybrid cannot be submitted early but becomes available only after required inspection',()=>{let s=g.reduce(g.createInitialState(ep),{type:A.START},ep);assert.equal(g.isDecisionAvailable(s,ep,'d_hybrid'),false);s=g.reduce(s,{type:A.GO_TO_DECISION},ep);let attempted=g.reduce(s,{type:A.SUBMIT_DECISION,decisionId:'d_hybrid'},ep);assert.equal(attempted,s);s=g.reduce(s,{type:A.BACK_TO_INVESTIGATION},ep);for(const id of ['e_monitor','e_controller'])s=g.reduce(s,{type:A.OPEN_EVIDENCE,evidenceId:id},ep);s=g.reduce(s,{type:A.CONSULT,advisorId:'boy'},ep);s=g.reduce(s,{type:A.OPEN_EVIDENCE,evidenceId:'e_clocksync'},ep);assert.equal(g.isDecisionAvailable(s,ep,'d_hybrid'),true);s=g.reduce(s,{type:A.GO_TO_DECISION},ep);s=g.reduce(s,{type:A.ACKNOWLEDGE_UNCERTAINTY,value:true},ep);s=g.reduce(s,{type:A.SUBMIT_DECISION,decisionId:'d_hybrid'},ep);assert.equal(s.outcomeId,'d_hybrid');const pm=g.buildPostmortem(s,ep);assert(pm.known.length===3);assert(pm.unknown.length>0)});
test('Opening scenes are player-paced and evidence names are present without leaking hidden clock on briefing',()=>{
 const js=read('script.js'),html=read('index.html');for(const id of ['sceneTitle','sceneIsolation','sceneAnomaly','sceneBriefing','sceneCrew','sceneInvestigation','sceneDecision','sceneOutcome','sceneDebrief'])assert(html.includes('id="'+id+'"'));
 assert(!/setTimeout\s*\(/.test(js));assert(js.includes('CORE.reduce'));assert(js.includes('CORE.isDecisionAvailable'));
 const before=html.slice(0,html.indexOf('id="sceneCrew"'));assert(!before.includes('six minutes'));
});
