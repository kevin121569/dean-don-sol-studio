# V3 Independent QA checkpoint — October 10, 2026

**Stage:** CANDIDATE browser prototype, hold from Android/release.

- PASS: static JS syntax (`node --check script.js` and `node --check canonical-core-bundle.js`).
- PASS: 9/9 automated source/logic tests. Four byte-pinned integrity checks (three game-core files plus episode content); initial 4 evidence sources, hidden clock reveal, changing TOOTH advice, fourth-option lock/unlock and postmortem, no story auto-advance.
- PASS: HTML has 9 unique story stages, 9 progress segments, zero duplicate IDs, and no missing hard-coded JS IDs.
- PASS: the bundled standalone HTML embeds CSS, SVGs, audio, episode data, core logic, and interactions; archive passes ZIP member-integrity check.
- NOT VERIFIED locally: local Chromium navigation is blocked by administrator policy, including file:// and http://localhost. Browser screenshot/interaction pass pending alternate hosted verification.
- NOT TESTED: real Motorola/Android audio, APK integration, device resume and save compatibility (this is a separate web-only preview).
- No change to official game, C1/C2/C3 APKs, approved V2 source, or production saves.

This report must be updated if hosted browser verification completes.

## Hosted real-Chrome QA (PASS, test run 38086158402)
The full V3 source ZIP was mounted in GitHub Actions, and Chrome at 390px and 1280px completed title → relay → alarm → static mission → advisers → evidence, including BOY's hidden clock reveal and staged TOOTH advice → locked/unlocked choices → canonical outcome → debrief → replay. The run passed without JavaScript page errors and produced 10 screenshots. Full recorded evidence was downloaded and ZIP-tested.

The initial screenshots were captured during fade-in, so a second passing run waited for the animation to settle. That review also revealed a minor **overlap between the scene label and the heading**; this final candidate moves the label to the upper margin. Since the latter is CSS only, source rules and player interactions are unchanged. A separate visual screenshot acceptance of the final layout is pending until the next hosted run.
